<?php
include("../db/db.php");
include("../../module_function/whatsapp_notification.php");

$sendData = json_decode($_POST['sendData'], true);
$ph_num = mysqli_real_escape_string($con, $sendData['ph_num']);
$otp = mysqli_real_escape_string($con, $sendData['otp']);

$execute = 1;
$new_user = "Yes";
$userName = "";
$previousLogin = 'No';

//check new user
$userDataget = mysqli_query($con, "select name, user_id from tbl_user_master where ph_num='" . $ph_num . "' ");
$userData = mysqli_fetch_row($userDataget);

if ($userData) {
	$new_user = "No";
	$userName = $userData[0];
	$user_id = $userData[1];

	// if user exist then check user previous logged in or not
	$user_token_dataget = mysqli_query($con, "select * from login_token_auth where user_code='" . $user_id . "' ");
	$user_token_data = mysqli_fetch_row($user_token_dataget);
	if ($user_token_data) {
		$previousLogin = 'Yes';
	}
}

// check otp
if ($execute == 1) {
	$dataget = mysqli_query($con, "select otp, valid_timestamp from tbl_otp_details where ph_num='" . $ph_num . "' ");
	$data = mysqli_fetch_row($dataget);

	$Valid_otp = $data[0];
	$valid_timestamp = $data[1];

	if ($valid_timestamp < $timestamp) {
		$status = "error";
		$status_text = "Sorry!! OTP Expired";
		$execute = 0;
	}

	if ($execute == 1) {
		if ($otp == $Valid_otp) {
			$status = "success";
			$status_text = "Congrats!! OTP Verified";
		} else {
			$status = "error";
			$status_text = "OTP entered is incorrect, Please try again";
		}
	}

	if ($execute == 1) {
		$phoneNumberGetData = mysqli_query($con, "SELECT DISTINCT(ph_num) FROM tbl_otp_details WHERE ph_num='" . $ph_num . "' ");
		$phoneNumberGet = mysqli_fetch_row($phoneNumberGetData);
		$phoneNumber = $phoneNumberGetData[0];

		if ($phoneNumber) {
			## if user not registered then send message to user
			$sendPhoneNumber = $phoneNumber;
			$sendTextMessage = "You haven't successfully logged in to your account. Kindly login to your account to continue.";
			sendWhatsappMessage();
		}
	}
}

$response = [
	'status' => $status,
	'status_text' => $status_text,
	'new_user' => $new_user,
	'userName' => $userName,
	'previousLogin' => $previousLogin,
];
echo json_encode($response, true);
