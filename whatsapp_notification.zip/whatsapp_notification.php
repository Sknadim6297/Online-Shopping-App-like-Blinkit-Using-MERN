<?php
function sendWhatsappMessage()
{

    global $sendPhoneNumber;
    global $sendTextMessage;

    $url = '';
    $accessToken = '';

    $headers = [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $accessToken
    ];

    $data = [
        'to' => $sendPhoneNumber,
        'type' => 'text',
        'text' => ['body' => $sendTextMessage]
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    curl_close($ch);

    if ($response['status'] == 'sent') {
        $response = true;
    } else {
        $response = false;
    }
}
